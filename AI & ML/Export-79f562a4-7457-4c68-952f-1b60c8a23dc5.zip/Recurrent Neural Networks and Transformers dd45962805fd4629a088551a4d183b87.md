# Recurrent Neural Networks and Transformers

- VERY USEFUL LINK!!!!!!!!!!!
    
    [Long Short-Term Memory (LSTM), Clearly Explained](https://www.youtube.com/watch?v=YCzL96nL7j0)
    
    [Illustrated Guide to LSTM's and GRU's: A step by step explanation](https://www.youtube.com/watch?v=8HyCNIVRbSU)
    
    [CS 230 - Recurrent Neural Networks Cheatsheet](https://stanford.edu/~shervine/teaching/cs-230/cheatsheet-recurrent-neural-networks)
    

[https://stanford.edu/~shervine/teaching/cs-230/cheatsheet-recurrent-neural-networks](https://stanford.edu/~shervine/teaching/cs-230/cheatsheet-recurrent-neural-networks)

---

**Architechture:** RNNs are a class of neural networks that allow previous outputs to be used as inputs while having hidden states. They are typically as follows

![Screenshot 2022-12-29 at 12.54.45 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_12.54.45_PM.png)

```python
# RNN from Scratch
class MyRNNCell(tf.keras.layers.Layer):
	def __init__(self, rnn_units, input_dim, output_dim):
		super(MyRNNCell, self).__init__()
		
		# Initialize weight matrices
		self.W_xh = self.add_weight([rnn_units, input_din])
		self.W_hh = self.add_weight([rnn_units, unn_units])
		self.W_hy = self.add_weight([output_dim, rnn_units])
		
		# Initialize hidden state to 0's
		self.h = tf.zeros([rnn_units, 1])
	def call(self, x):

		self.h = tf.math.tanh(self.W_hh*self.h + self.W_xh*x)
		
		output = self.W_hy * self.h
	
		# return current output & hiddenstate
		return output, self.h
```

Implementation in Tensorflow

<aside>
💡 tf.keras.layers.SimpleRNN(rnn_units)

</aside>

![Screenshot 2022-12-30 at 10.51.08 AM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-30_at_10.51.08_AM.png)

![Screenshot 2022-12-30 at 10.49.59 AM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-30_at_10.49.59_AM.png)

---

| Pros | Cons |
| --- | --- |
| possibility of processing input of any length | Computation begin slow |
| model size not increasing with size of input | difficulty of accessing information from a long time ago |
| Computation take into account historical imformation | cannot consider any future input for the current state |
| weights are shared across time |  |

### RNNs for Sequence Modeling

**Application** - RNN models are mostly used in the fields of natural language processing and speech recognition.

![Screenshot 2022-12-29 at 1.07.17 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.07.17_PM.png)

| one-to-one | Traditional neural network |
| --- | --- |
| one-to-many | music generation |
| many-to-one | sentiment classification |
| many-to-many | name entity recognition |
| many-to-many | machine translation |
- One to One NN (Binary Classification) - Traditional neural network
- Many to One Sentiment Classification
- One to Many (Text Generation, Image Captioning)
- Many to Many (Translation & Forecasting Music Generation)

---

### Sequence Modelling: Design Criteria

To model sequences, we need to:

1. Handle **variable-length** sequences
2. Track **long-term** dependencies
3. Maintain information about **order**
4. **Share parameters** across the sequence

---

### A Sequence Modelling Problem: Predict the Next Word

“This morning i took my cat for *a walk*.’’ 

“The food was *great*.”

![Screenshot 2022-12-29 at 1.23.04 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.23.04_PM.png)

**Encoding Language for a Neural Network**

![Screenshot 2022-12-29 at 1.25.56 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.25.56_PM.png)

### Capture Differences in Sequence Order

### Loss function (L)

the loss function is defined based on the loss at every time step.

![Screenshot 2022-12-30 at 11.02.02 AM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-30_at_11.02.02_AM.png)

---

### Backpropagation through time

Backpropagation is done at each point in time.

At timestep **T**, the derivative of the loss **L** with respect to weight matrix **W** is expressed as follows.

![Screenshot 2022-12-30 at 11.04.31 AM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-30_at_11.04.31_AM.png)

---

### Model Long-Term Dependencies

- **Commonly used activation functions**
    - sigmoid, tanh, RELU
- **Vanishing/ exploding gradient**
- **Gradient clipping**

![Screenshot 2022-12-29 at 1.30.15 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.30.15_PM.png)

![Screenshot 2022-12-29 at 1.30.35 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.30.35_PM.png)

![Screenshot 2022-12-29 at 1.30.44 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2022-12-29_at_1.30.44_PM.png)

## Different RNN Architectures

- Bidirectional Recurrent Neural Networks (BRNN)
- Gated Recurrent Units (GRU)

### Long Short Term Memory (LSTM) **

- design to vanishing gradient problem in RNNs.
- use 3 gates called input output forget gate.
    - remark**
        1. **forget gate**: [$h_{t-1},x_t$] decide how much of the cell state to forget.
            - the forget gate take a sigmoid
                
                ![Screenshot 2023-01-05 at 10.19.58 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.19.58_PM.png)
                
            - the contents of the output have a range of (0, 1). A value of 1 means keep it, and a value of 0 means forget it.
            - LSTM then use element-wise multiplication $C_{t-1} * f_t$ to forget the corresponding information in the cell state.
        2. **input gate**: the input gate inject [$h_{t-1},x_t$] to the cell state after forgetting some information.
            1. the first part of input gate: is sigmoid neural that decides how much of the input to filter out (very simlilar to the forget gate layer .
                
                ![filter out](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.20.37_PM.png)
                
                filter out
                
            2. the second part is a tanh neural that creates possible new additions to the cell state 
                
                ![create possible new additions](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.20.45_PM.png)
                
                create possible new additions
                
            3. we then compute multiplication $ç*i_t$ and add to the cell state after the forget gate to get the new cell state
                
                ![new cell state](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.22.32_PM.png)
                
                new cell state
                
        3. **output gate** 
            
            ![Screenshot 2023-01-05 at 10.27.16 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.27.16_PM.png)
            
            ![Screenshot 2023-01-05 at 10.28.13 PM.png](Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87/Screenshot_2023-01-05_at_10.28.13_PM.png)
            
        
        note: the cell state and output are carried over and inputted into the next time step.
        

### Bi-Long Short Term Memory (LSTM)

- frequently use in sequence to sequence tasks
- use to predict in two ways ( forward & backward)

[Bi-LSTM](https://medium.com/@raghavaggarwal0089/bi-lstm-bc3d68da8bd0)