# DEEP LEARNING

---

[introduction](DEEP%20LEARNING%20b387edaf6bfd4e05aef3b668a2901907/introduction%200a6df4f536704b96a10d2b049b988416.md)

[Recurrent Neural Networks and Transformers](DEEP%20LEARNING%20b387edaf6bfd4e05aef3b668a2901907/Recurrent%20Neural%20Networks%20and%20Transformers%20dd45962805fd4629a088551a4d183b87.md)